import React, {Component} from 'react'
import {View, Text} from 'react-native'



export default class Favorite extends Component {
    
    render() {
        return(
            <Text>Favorite</Text>
        )
    }
}